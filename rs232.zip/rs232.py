import serial
import time

# Open UART
ser = serial.Serial(
    port="/dev/serial0",   # UART device on Pi4
    baudrate=115200,
    timeout=1
)

time.sleep(0.1)  # Short delay to ensure UART is ready

try:
    while True:
        name = "Ceyhun Pempeci\r\n"
        ser.write(name.encode("utf-8"))
        print(f"Sent: {name.strip()}")
        time.sleep(1)  # Wait 1 second

except KeyboardInterrupt:
    print("\nStopped by user.")

finally:
    ser.close()

